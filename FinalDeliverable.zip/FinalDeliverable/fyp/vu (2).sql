-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 31, 2018 at 07:40 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vu`
--

-- --------------------------------------------------------

--
-- Table structure for table `cakes`
--

CREATE TABLE `cakes` (
  `cake_id` int(11) NOT NULL,
  `cake_name` varchar(100) NOT NULL,
  `cake_category` varchar(100) NOT NULL,
  `cake_price` int(100) NOT NULL,
  `cake_pic` varchar(200) NOT NULL,
  `cake_description` text NOT NULL,
  `cake_created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cakes`
--

INSERT INTO `cakes` (`cake_id`, `cake_name`, `cake_category`, `cake_price`, `cake_pic`, `cake_description`, `cake_created_at`) VALUES
(12, 'Chocolate Cake', 'Birthday', 123, 'images.jpg', 'cake for Birthday ', '2018-10-31 23:36:01'),
(13, 'Black Forest Cake', 'Eid', 123, 'download.jpg', 'Eid Cake Here', '2018-10-31 23:36:52');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_cake_id` int(100) NOT NULL,
  `order_user_id` int(100) NOT NULL,
  `order_cake_size` varchar(100) DEFAULT NULL,
  `order_cake_status_admin` tinyint(1) DEFAULT NULL,
  `order_cake_status_user` tinyint(1) DEFAULT NULL,
  `order_created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_cake_id`, `order_user_id`, `order_cake_size`, `order_cake_status_admin`, `order_cake_status_user`, `order_created_at`) VALUES
(22, 8, 1, '-4', 1, 1, '2018-10-07 13:02:41'),
(23, 8, 2, '1', NULL, 0, '2018-10-07 13:22:15'),
(24, 8, 1, NULL, NULL, NULL, '2018-10-15 05:07:25'),
(25, 11, 3, '6', NULL, 1, '2018-10-28 12:28:37'),
(26, 13, 5, '2', NULL, 1, '2018-10-31 18:38:04');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` int(1) DEFAULT NULL COMMENT '1 for admin',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `role`, `created_at`) VALUES
(4, 'sadia', 'sadia@gmail.com', '202cb962ac59075b964b07152d234b70', 1, '2018-10-31 23:24:26'),
(5, 'sadiuser', 'sadi@user.com', '202cb962ac59075b964b07152d234b70', NULL, '2018-10-31 23:37:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cakes`
--
ALTER TABLE `cakes`
  ADD PRIMARY KEY (`cake_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cakes`
--
ALTER TABLE `cakes`
  MODIFY `cake_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
